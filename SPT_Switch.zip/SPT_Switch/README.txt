Made by Lejam009- /2025
Version 1.00
Report any issues @ (Discord) lejam009_
┌─────────────────────────────────────────┐
│ This work is free of charge             │
│ If you paid money, you were scammed     │
│ Commercial use is prohibited            │
└─────────────────────────────────────────┘
;)